<script src="{{ url('admin/assets/libs/jquery/dist/jquery.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/jquery-slimscroll/jquery.slimscroll.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/jquery-sparkline/jquery.sparkline.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/chartist/dist/chartist.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/chartist-plugin-threshold/dist/chartist-plugin-threshold.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/raphael/raphael.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/morris.js/morris.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/gaugeJS/dist/gauge.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/chart.js/dist/Chart.bundle.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/c3/c3.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/d3/dist/d3.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/inputmask/dist/jquery.inputmask.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/parsleyjs/dist/parsley.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/select2/dist/js/select2.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/multiselect/js/jquery.multi-select.js') }}"></script>
<script src="{{ url('admin/assets/libs/fullcalendar/main.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/cropperjs/dist/cropper.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/sortablejs/Sortable.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/jquery-nestable/jquery.nestable.js') }}"></script>
<script src="{{ url('admin/assets/libs/jquery-asColor/dist/jquery-asColor.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/jquery-asGradient/dist/jquery-asGradient.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/jquery-asColorPicker/dist/jquery-asColorPicker.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/%40claviska/jquery-minicolors/jquery.minicolors.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/datatables.net/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/datatables.net-buttons/js/buttons.html5.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/datatables.net-buttons/js/buttons.print.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/datatables.net-buttons/js/buttons.colVis.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/datatables.net-rowgroup/js/dataTables.rowGroup.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/datatables.net-select/js/dataTables.select.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/daterangepicker/moment.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/daterangepicker/daterangepicker.js') }}"></script>
<script src="{{ url('admin/assets/libs/tempusdominus-bootstrap-4/build/js/tempusdominus-bootstrap-4.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/bootstrap-select/dist/js/bootstrap-select.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/jvectormap-next/jquery-jvectormap.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/ika.jvectormap/jquery-jvectormap-us-aea-en.js') }}"></script>
<script src="{{ url('admin/assets/libs/cd-jvectormap/world-mill.js') }}"></script>
<script src="{{ url('admin/assets/libs/gmaps/gmaps.min.js') }}"></script>
<script src="{{ url('admin/assets/libs/quill/dist/quill.min.js') }}"></script>


<!-- clipboard -->
{{-- <script src="../../../../../cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.5.12/clipboard.min.js"></script> --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.5.12/clipboard.min.js" integrity="sha512-KFWecP2K4Gw2jaWso5S9+6pOt0/Kb9O5QI/itUPLoXajRaRqLXVMPfyBWtf75VB0DO7hBhbyMINtXdLfiYrqWQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.11.4/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js" integrity="sha512-rstIgDs0xPgmG6RX1Aba4KV5cWJbAMcvRCVmglpam9SoHZiUCyQVDdH2LPlxoHtrv17XWblE/V/PP+Tr04hbtA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
{{-- <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script> --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- Theme JS -->
<script src="{{ url('admin/assets/js/theme.min.js') }}"></script>

<script>
    $(document).ready(function() {
        $('.select2').select2({
			placeholder: "Select",
			allowClear: true
	    });
        $('[data-toggle="tooltip"]').tooltip();

        $('body').tooltip({
            selector: '[data-toggle="tooltip"]'
        });

        setTimeout(() => {
            $("#DataTables_Table_0").removeAttr("style");
        }, 500)
    });
</script>
