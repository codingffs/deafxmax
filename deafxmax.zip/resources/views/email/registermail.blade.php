<h1>New User Registration</h1>
<p>Email: {{ $User->email }}</p>
<p>Password: {{ $password }}</p>
