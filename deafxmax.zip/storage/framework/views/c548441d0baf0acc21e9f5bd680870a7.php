<?php $__env->startSection('content'); ?>
    <div class="container-fluid dashboard-content">
        <div class="row">
            <div class="col-xl-10">
            <!-- ============================================================== -->
            <!-- pageheader  -->
            <!-- ============================================================== -->
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header" id="top">
                    <h2 class="pageheader-title">Create Withdraw </h2>
                    <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-link">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('withdraw.index')); ?>" class="breadcrumb-link">Withdraw</a></li>
                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Create Withdraw</a></li>
                        </ol>
                    </nav>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
              <div class="card mb-5 shadow-sm">
                <h5 class="card-header">Create Withdraw</h5>
                <div class="card-body">
                  <form method="post" action="<?php echo e(route('withdraw.store')); ?>" id="add_members" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-2 input_select2">
                        <div class="input-group-prepend"><span class="input-group-text"><i class="fa fa-building"></i></span></div>
                        <select class="form-control select2 sub_category" id="input-select" name="withdraw_type" required>
                            <option selected disabled>-- Select Withdraw --</option>
                            <option>Principle</option>
                            <option>Profit</option>
                            <option>Team</option>
                        </select>
                    </div>
                    <?php $__errorArgs = ['withdraw_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     <div class="input-group mb-2">
                        <div class="input-group-prepend"><span class="input-group-text"><i class="fa fa-inr"></i></span></div>
                        <input id="amount" type="text" class="form-control" name="amount" placeholder="Amount*" value="<?php echo e(old('amount')); ?>" pattern="[0-9]+" maxlength="20" minlength="0" required>
                    </div>
                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>
                    <button type="submit" class="btn btn-primary mt-2">Submit</button>
                    <a href="<?php echo e(route('withdraw.index')); ?>" class="btn btn-secondary mt-2">Cancel</a>
                  </form>
                </div>
              </div>
            </div>
          </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin_script'); ?>
<script>
    $(document).ready(function() {
        $('#add_members').validate({
            errorPlacement: function(error, element) {
                if (element.attr("name") == "name") {
                    error.insertAfter( element.parent("div"));
                } else {
                    error.insertAfter( element.parent("div"));
                }
            },
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deafxmax\resources\views/admin/withdraw/create.blade.php ENDPATH**/ ?>