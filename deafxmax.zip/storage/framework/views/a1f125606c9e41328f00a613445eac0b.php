<?php $__env->startSection('content'); ?>
    <!-- wrapper  -->
    <!-- ============================================================== -->
      <div class="dashboard-influence">
        <div class="container-fluid dashboard-content">
          <!-- ============================================================== -->
          <!-- pageheader  -->
          <!-- ============================================================== -->
          <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
              <div class="page-header">
                <h2 class="mb-2">Dashboard </h2>
                <p class="pageheader-text">Proin placerat ante duiullam scelerisque a velit ac porta, fusce sit amet
                  vestibulum mi. Morbi lobortis pulvinar quam.</p>
                <div class="page-breadcrumb">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-link">Dashboard</a></li>
                      
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
          <!-- ============================================================== -->
          <!-- end pageheader  -->
          <!-- ============================================================== -->
          <!-- ============================================================== -->
          <!-- content  -->
          <!-- ============================================================== -->
          <!-- ============================================================== -->
          <!-- influencer profile  -->
          <!-- ============================================================== -->
          
          <!-- ============================================================== -->
          <!-- end influencer profile  -->
          <!-- ============================================================== -->
          <!-- ============================================================== -->
          <!-- widgets   -->
          <!-- ============================================================== -->
          <div class="row">
            <!-- ============================================================== -->
            <!-- four widgets   -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- total views   -->
            <!-- ============================================================== -->
            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
              <div class="card mb-5 shadow-sm">
                <div class="card-body bg_gradiant1">
                  <div class="d-inline-block">
                    <?php if(auth()->user()->role_id == 2): ?>
                    <h5 class="text-white mb-3">Profit Sharing Income</h5>
                    <h2 class="mb-0 text-white">$<?php echo e(get_profit_income_count()); ?></h2>
                    <?php else: ?>
                    <h5 class="text-white mb-3">Total Views</h5>
                    <h2 class="mb-0 text-white">10,28,056</h2>
                    <?php endif; ?>
                  </div>
                  <div class="float-right icon-shape icon-xl rounded-circle  bg-info-light mt-1">
                    <i class="fas fa-hand-holding-usd fa-fw fa-sm text-info font-24"></i>
                  </div>
                </div>
              </div>
            </div>
            <!-- ============================================================== -->
            <!-- end total views   -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- total followers   -->
            <!-- ============================================================== -->
            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
              <div class="card  mb-5 shadow-sm">
                <div class="card-body bg_gradiant2">
                  <div class="d-inline-block">
                    <?php if(auth()->user()->role_id == 2): ?>
                    <h5 class="text-white mb-3">Team Income</h5>
                    <h2 class="mb-0 text-white">$<?php echo e(get_team_income_count()); ?></h2>
                    <?php else: ?>
                    <h5 class="text-white mb-3">Total Views</h5>
                    <h2 class="mb-0 text-white">10,28,056</h2>
                    <?php endif; ?>
                  </div>
                  <div class="float-right icon-shape icon-xl rounded-circle  bg-primary-light mt-1">
                    <i class="fa fa-group fa-fw fa-sm text-primary font-24"></i>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="card mb-5 shadow-sm">
                  <div class="card-body bg_gradiant1">
                    <div class="d-inline-block">
                      <?php if(auth()->user()->role_id == 2): ?>
                      <h5 class="text-white mb-3">Principal Amount</h5>
                      <h2 class="mb-0 text-white">$<?php echo e(get_principal_amount_count()); ?></h2>
                      <?php else: ?>
                      <h5 class="text-white mb-3">Total Views</h5>
                      <h2 class="mb-0 text-white">10,28,056</h2>
                      <?php endif; ?>
                    </div>
                    <div class="float-right icon-shape icon-xl rounded-circle  bg-info-light mt-1">
                      <i class="fas fa-inr fa-fw fa-sm text-info font-24"></i>
                    </div>
                  </div>
                </div>
              </div>
            <!-- ============================================================== -->
            <!-- end total followers   -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- partnerships   -->
            <!-- ============================================================== -->
            
            <!-- ============================================================== -->
            <!-- end partnerships   -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- total earned   -->
            <!-- ============================================================== -->
            
            <!-- ============================================================== -->
            <!-- end total earned   -->
            <!-- ============================================================== -->
          </div>
          <!-- ============================================================== -->
          <!-- end widgets   -->
          <!-- ============================================================== -->
          
          
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deafxmax\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>