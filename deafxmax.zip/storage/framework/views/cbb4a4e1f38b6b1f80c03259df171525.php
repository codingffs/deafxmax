<?php $__env->startSection('content'); ?>
    <div class="container-fluid dashboard-content">
        <div class="row">
            <div class="col-xl-10">
            <!-- ============================================================== -->
            <!-- pageheader  -->
            <!-- ============================================================== -->
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header" id="top">
                    <h2 class="pageheader-title">View Parent Member</h2>
                    <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-link">Home</a></li>
                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link"> Parent Member</a></li>
                        </ol>
                    </nav>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
              <div class="card mb-5 shadow-sm">
                <h5 class="card-header">View Parent Member</h5>
                <div class="card-body">
                    <?php echo csrf_field(); ?>
                    <table id="datatable1"class="view_parenttable table table-hover mb-0">
                        <thead>
                            <tr>
                              <th>Name</th>
                              <th>Email</th>
                              <th>Mobile Number</th>
                              <th>Profit Income</th>
                              <th>Team Income</th>
                              <th>Pancard Number</th>
                              <th>Bank Account Number</th>
                              <th>Created Date</th>
                              <th>Actions</th>
                              <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($kyc != '[]'): ?>
                                <?php $__currentLoopData = $kyc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $User): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($User->label_name); ?></td>
                                        <td><?php echo e($User->email); ?></td>
                                        <td><?php echo e($User->mobile_no); ?></td>
                                        <td><?php echo e($User->profit_income); ?></td>
                                        <td><?php echo e($User->team_income); ?></td>
                                        <td><?php echo e($User->pancard_no); ?></td>
                                        <td><?php echo e($User->bank_act_no); ?></td>
                                        <td><?php echo e($User->date_member); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('members.edit',$User->id)); ?>" data-id="<?php echo e($User->id); ?>" class="table-action-btn edit btn btn-primary m-1" ><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                            <a href="javascript:void(0)" data-url="<?php echo e(route('members_destroy',$User->id)); ?>" class="table-action-btn btn btn-danger m-1 delete_btn" data-id="<?php echo e($User->id); ?>   "><i class="fa fa-trash" aria-hidden="true"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center">No Data Found</td>
                                    <tr>
                                <?php endif; ?>
                      </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin_script'); ?>
<script>
    $(document).ready(function () {
        $(document).on('click', ".approve_btn", function() {
            swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonClass: "btn btn-success",
                cancelButtonClass: "btn btn-primary",
                confirmButtonText: 'Yes, aprove it!',
                inputValidator: (value) => {
                    if (!value) {
                        return 'You need to write something!'
                    }
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    var url = $(this).attr('data-href');
                    var token = '<?php echo csrf_token(); ?>';
                    $.ajax({
                        type: 'GET',
                        contentType: "application/json; charset=utf-8",
                        url: url,
                        data: {
                            _token: token,
                            _method: 'DELETE',
                        },
                        success: function(data) {
                          console.log(data);
                            if (data.status == 1) {
                            window.location.href = "<?php echo e(route('members.index')); ?>";
                            }
                            else{
                                return false;
                            }
                        }
                    });
                }
            });
        });
        $(document).on('click', ".delete_btn", function(event) {
                  swal.fire({
                      title: 'Are you sure?',
                      text: "You won't be able to revert this!",
                      icon: 'warning',
                      showCancelButton: true,
                      confirmButtonClass: "btn btn-danger",
                      cancelButtonClass: "btn btn-primary",
                      confirmButtonText: 'Yes, delete it!',
                      inputValidator: (value) => {
                          if (!value) {
                              return 'You need to write something!'
                          }
                      }
                  }).then((result) => {
                      if (result.isConfirmed) {
                          var url = $(this).attr('data-url');
                          var token = '<?php echo csrf_token(); ?>';
                          $.ajax({
                              type: 'GET',
                              url: url,
                              success: function(data) {
                                if(data.status == 0){
                                    window.location.reload();
                                    toastr_success(" Parent Member Deleted Successfully");
                                }
                              }
                          });
                      }
                    });
                });
      });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deafxmax\resources\views/admin/members/parent_data.blade.php ENDPATH**/ ?>