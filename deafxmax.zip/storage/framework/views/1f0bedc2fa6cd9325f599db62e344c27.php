<div class="nav-left-sidebar sidebar-dark">
    <div class="menu-list">
      <nav class="navbar navbar-expand-lg navbar-light">
        <a class="d-xl-none d-lg-none text-white" href="#">Dashboard</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
          aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav flex-column">
            <li class="nav-item">
              <a class="nav-link <?php echo e(routeActive('dashboard')); ?> " href="<?php echo e(route('dashboard')); ?>"  aria-expanded="false">
                <i class="fa fa-fw fa-user-circle"></i>Dashboard
              </a>
            </li>
            
            <?php if(auth()->user()->role_id == 1): ?>
            <li class="nav-item">
              <a class="nav-link <?php echo e(routeActive('setting.index')); ?><?php echo e(routeActive('setting.create')); ?><?php echo e(routeActive('setting.edit')); ?>" href="<?php echo e(route('setting.index')); ?>"  aria-expanded="false">
                <i class="fa fa-cog"></i>Setting
              </a>
            </li>
            <?php endif; ?>
            <?php if(auth()->user()->role_id == 2): ?>
            <li class="nav-item">
              <a class="nav-link <?php echo e(routeActive('members.index')); ?><?php echo e(routeActive('members.create')); ?><?php echo e(routeActive('members.edit')); ?><?php echo e(routeActive('members.destroy')); ?>" href="<?php echo e(route('members.index')); ?>" aria-expanded="false">
                <i class="fa fa-users"></i>Members List
              </a>
            </li>
            <?php else: ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(routeActive('members.index')); ?><?php echo e(routeActive('members.create')); ?><?php echo e(routeActive('members.edit')); ?><?php echo e(routeActive('members.destroy')); ?>" href="<?php echo e(route('members.index')); ?>" aria-expanded="false">
                  <i class="fa fa-users"></i>Members
                </a>
              </li>
            <?php endif; ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(routeActive('depositdetails.index')); ?><?php echo e(routeActive('depositdetails.create')); ?>" href="<?php echo e(route('depositdetails.index')); ?>" aria-expanded="false">
                    <i class="fas fa-hand-holding-usd"></i>Deposit Details
                </a>
              </li>
              <?php if(auth()->user()->role_id == 2): ?>
              <li class="nav-item">
                <a class="nav-link <?php echo e(routeActive('withdraw.index')); ?><?php echo e(routeActive('withdraw.create')); ?>" href="<?php echo e(route('withdraw.index')); ?>" aria-expanded="false">
                    <i class="fa fa-money"></i>WithDraw Details
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('bank_details')); ?>" aria-expanded="false"><i class="fa fa-bank"></i>My Bank Details
                </a>
              </li>
              <?php if(getKycFlag() == 1): ?>
              <li class="nav-item">
                <a class="nav-link " href="<?php echo e(route('kyc.create')); ?>" aria-expanded="false">
                    <i class="fas fa-user-check mr-2"></i>Kyc Create
                </a>
              </li>
              <?php endif; ?>
            <?php endif; ?>
            <?php if(auth()->user()->role_id == 1): ?>
              <li class="nav-item">
                <a class="nav-link <?php echo e(routeActive('notification')); ?>" href="<?php echo e(route('notification')); ?>" aria-expanded="false">
                    <i class="fas fa-eye"></i> View WithDraw
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#" aria-expanded="false">
                    <i class="fas fa-user-check mr-2"></i>Complete Kyc
                </a>
              </li>
            <?php endif; ?>
            <li class="nav-item">
                <a class="nav-link " href="<?php echo e(route('logout')); ?>" aria-expanded="false">
                    <i class="fas fa-power-off mr-2"></i>Logout
                </a>
              </li>
          </ul>
        </div>
      </nav>
    </div>
  </div>
<?php /**PATH C:\xampp\htdocs\deafxmax\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>