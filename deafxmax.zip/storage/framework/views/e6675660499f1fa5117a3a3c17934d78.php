<link rel="stylesheet" href="<?php echo e(url('admin/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link href="https://cdn.datatables.net/1.11.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(url('admin/assets/libs/fullcalendar/main.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('admin/assets/libs/quill/dist/quill.snow.css')); ?>">
<!-- Theme CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<link rel="stylesheet" href="<?php echo e(url('admin/assets/css/theme.min.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<link rel="stylesheet" href="<?php echo e(url('admin/assets/css/custom.css')); ?>">
<?php /**PATH C:\xampp\htdocs\deafxmax\resources\views/admin/layout/css.blade.php ENDPATH**/ ?>