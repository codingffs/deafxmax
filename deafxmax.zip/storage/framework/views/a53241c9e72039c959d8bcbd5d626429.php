<!doctype html>
<html lang="en">


<!-- Mirrored from preview.easetemplate.com/influence/html/influence/pages/forgot-password.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 27 Mar 2023 06:16:51 GMT -->
<head>

  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="../assets/images/favicon.ico" type="image/x-icon">


  <!-- Libs CSS -->
  <?php if ($__env->exists('admin.layout.css')) echo $__env->make('admin.layout.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <title>Forgot Password - Influence Bootstrap Admin Dashboard Template</title>

</head>

<body class="bg-light">
  <!-- ============================================================== -->
  <!-- forgot password  -->
  <!-- ============================================================== -->
  <div class="min-vh-100 d-flex align-items-center">
    <div class="splash-container">
      <div class="card shadow-sm">
        <div class="card-header text-center"><img class="logo-img" src="<?php echo e(url('admin/assets/images/logo.png')); ?>" alt="logo"><span
            class="splash-description">Please enter your user information.</span></div>
        <div class="card-body">
          <form method="post" id="forgot_pass_form">
            <?php echo csrf_field(); ?>
            <p>Don't worry, we'll send you an email to reset your password.</p>
            <div class="form-group mb-2">
              <input class="form-control" type="email" name="email" required="" placeholder="Your Email"
                autocomplete="off">
            </div>
            
            <button type="submit" class="btn btn-block btn-primary btn-x">Reset Password</button>
          </form>
        </div>
        
      </div>
    </div>
  </div>
  <!-- ============================================================== -->
  <!-- end forgot password  -->
  <!-- ============================================================== -->
  <!-- Libs JS -->
  <?php if ($__env->exists('admin.layout.js')) echo $__env->make('admin.layout.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function() {
            $("#forgot_pass_form").validate();
        });
    </script>
</body>
<!-- Mirrored from preview.easetemplate.com/influence/html/influence/pages/forgot-password.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 27 Mar 2023 06:16:51 GMT -->
</html>
<?php /**PATH C:\xampp\htdocs\deafxmax\resources\views/admin/forgot-password.blade.php ENDPATH**/ ?>