<!doctype html>
<html lang="en">


<!-- Mirrored from preview.easetemplate.com/influence/html/influence/pages/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 27 Mar 2023 06:16:50 GMT -->
<head>

  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="<?php echo e(url('admin/assets/images/favicon.ico')); ?>" type="image/x-icon">

  <!-- Libs CSS -->
  <?php if ($__env->exists('admin.layout.css')) echo $__env->make('admin.layout.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <title>Register</title>
</head>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
<p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<body class="bg-light">
  <!-- ============================================================== -->
  <!-- login page  -->
  <!-- ============================================================== -->
  <div class="min-vh-100 d-flex align-items-center">
    <div class="splash-container">
      <div class="card shadow-sm">
        <div class="card-header text-center">
          <a href="../index-2.html"><img class="logo-img" src="<?php echo e(getlogo('logo') != null ? getlogo('logo') : url('admin/assets/images/logo1.png')); ?>"width="100%" alt="logo"></a><span
            class="splash-description">Please enter your information.</span></div>
        <div class="card-body">
          <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-danger"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <form action="<?php echo e(route('register_submit')); ?>" method="POST" id="register_form" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <label for="Email">Email<span class="text-danger">*</span></label>
            <div class="form-group mb-2">
              <input type="text" name="email" class="form-control" id="email"  placeholder="Email"  autocomplete="off" required >
            </div>
            <label for="Password">Password<span class="text-danger">*</span></label>
            <div class="form-group mb-2">
              <input type="text" name="password" class="form-control" id="password"  placeholder="Password"  autocomplete="off" required>
            </div>
            <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- ============================================================== -->
  <!-- end login page  -->
  <!-- ============================================================== -->
  <!-- Libs JS -->
  <?php if ($__env->exists('admin.layout.js')) echo $__env->make('admin.layout.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script>
    $(document).ready(function() {
        $("#register_form").validate({
          rules:{
                mobile_no: {
                    required: true,
                    digits: true,
                },
                password: {
                    required: true,
                },
                },
            errorElement: 'span',
                errorPlacement: function (error, element) {
                error.addClass('invalid-feedback');
                element.closest('.form-group').append(error);
            },
            highlight: function (element, errorClass, validClass) {
                $(element).addClass('is-invalid');
            },
            unhighlight: function (element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
            }
        });
        $("#mobile_no").keypress(function (e) {
            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                     return false;
            }
        });
    });
    </script>
</body>
<!-- Mirrored from preview.easetemplate.com/influence/html/influence/pages/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 27 Mar 2023 06:16:50 GMT -->
</html>
<?php /**PATH C:\xampp\htdocs\deafxmax\resources\views/admin/register.blade.php ENDPATH**/ ?>