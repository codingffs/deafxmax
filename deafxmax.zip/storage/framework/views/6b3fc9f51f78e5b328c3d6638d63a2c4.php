<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="<?php echo e(getlogo('favicon') != null ? getlogo('favicon') : url('admin/assets/images/favicon.ico')); ?>" type="image/x-icon">


  <!-- Libs CSS -->
  <?php if ($__env->exists('admin.layout.css')) echo $__env->make('admin.layout.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('admin_css'); ?>
  
  <title>DeafxMax Best Health Insurance India Admin Dashboard</title>
</head>

<body>
  <!-- ============================================================== -->
  <!-- main wrapper -->
  <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
            <?php if ($__env->exists('admin.layout.header')) echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if ($__env->exists('admin.layout.sidebar')) echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="dashboard-wrapper">
            <?php echo $__env->yieldContent('content'); ?>
            <?php if ($__env->exists('admin.layout.footer')) echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<!-- ============================================================== -->
<!-- end main wrapper  -->
<!-- ============================================================== -->
<!-- Libs JS -->
<?php if ($__env->exists('admin.layout.js')) echo $__env->make('admin.layout.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('admin_script'); ?>
<?php if ($__env->exists('admin.layout.toastr')) echo $__env->make('admin.layout.toastr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\deafxmax\resources\views/admin/layout/master.blade.php ENDPATH**/ ?>