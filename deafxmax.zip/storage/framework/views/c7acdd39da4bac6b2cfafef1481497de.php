<h1>New User Registration</h1>
<p>Email: <?php echo e($User->email); ?></p>
<p>Password: <?php echo e($password); ?></p>
<?php /**PATH C:\xampp\htdocs\deafxmax\resources\views/email/registermail.blade.php ENDPATH**/ ?>